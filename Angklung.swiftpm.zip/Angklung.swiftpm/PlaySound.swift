//
//  PlaySound.swift
//  WWDC23
//
//  Created by Eldrick Loe on 09/04/23.
//

import Foundation
import AVFoundation
import AVKit

var player : AVAudioPlayer!

func playSound(key: String){
    guard let url = Bundle.main
        .url(forResource: key, withExtension: "wav") else{
            print("failed")
            return
        }
//    guard url != nil else{
//        print("failed")
//        return
//    }
    
    do{
        player = try AVAudioPlayer(contentsOf: url)
        player?.play()
    }catch{
        print("error")
    }
}
