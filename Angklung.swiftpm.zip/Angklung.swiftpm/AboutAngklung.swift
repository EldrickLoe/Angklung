//
//  AboutAngklung.swift
//  Angklung
//
//  Created by Eldrick Loe on 09/04/23.
//

import SwiftUI

struct AboutAngklung: View{
    @State private var currentFact = 0
    
    let angklungImage = ["Hi", "Angklung1", "Angklung2", "Angklung3", "Angklung_full", "Challenge"]
    let angklungFacts = ["Hi, are you interested about Angklung? Let's learn about Angklung together", "Angklung is a traditional musical instrument from Java, Indonesia. Angklung is made from bamboo tubes of different sizes. Each tube produces a different pitch, and when played together in a group, they create a beautiful and unique sound.", "What's especially fascinating about Angklung is the way it's played. It's not played with hands or with a bow, like many other instruments. Instead, it's played by shaking the instrument, which causes the bamboo tubes to vibrate and produce sound. The players typically stand in a row or circle and shake their Angklungs in a coordinated way to create a harmonious melody.", "Angklung has a rich history and cultural significance in Indonesia. It's often used in traditional ceremonies and celebrations, and is considered a symbol of community and togetherness. In recent years, it has also gained popularity around the world, and many musicians and enthusiasts have embraced it as a unique and fascinating instrument.", "Overall, Angklung is a fascinating and beautiful instrument that is sure to capture the interest of anyone who hears it. Its unique sound and cultural significance make it a truly special musical instrument that is worth learning more about.", "That's all about angklung, now I would like to challenge you to answer the following quiz to find out if you know about angklung?"]
    
    var body: some View{
        VStack(alignment: .center, spacing: 20){
            Spacer()
            Image(angklungImage[currentFact])
                .resizable()
                .scaledToFit()
            JustifiedText(angklungFacts[currentFact], font: .systemFont(ofSize: 32))
                .frame(width: 900, height: 250)
            Spacer()
            HStack{
                if(currentFact < 5){
                    Spacer()
                    if(currentFact > 0){
                        Button{
                            currentFact -= 1
                        }label : {
                            Text("Previous")
                                .frame(width: 200, height: 60)
                                .font(.system(size: 38))
                                .foregroundColor(Color.white)
                                .background(Color.brown)
                                .buttonStyle(.bordered)
                                .cornerRadius(10)
                        }
                        Spacer()
                    }
                    Button{
                        currentFact += 1
                    }label : {
                        Text("Next")
                            .frame(width: 200, height: 60)
                            .font(.system(size: 38))
                            .foregroundColor(Color.white)
                            .background(Color.brown)
                            .buttonStyle(.bordered)
                            .cornerRadius(10)
                    }
                    Spacer()
                }
                else{
                    NavigationLink( destination: Quiz(), label:{
                        Text("Quiz")
                            .frame(width: 400, height: 80)
                            .font(.system(size: 42))
                            .foregroundColor(Color.white)
                            .background(Color.brown)
                            .buttonStyle(.bordered)
                            .cornerRadius(10)
                    }
                    )
                }
            }
            Spacer()
        }
        .background(Image("batik")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .opacity(0.4)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .edgesIgnoringSafeArea(.all))
        //        .background(Color(red: 243/255, green: 222/255, blue: 186/255))
    }
}
