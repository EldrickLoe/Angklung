//
//  Quiz.swift
//  Angklung
//
//  Created by Eldrick Loe on 09/04/23.
//

import SwiftUI

struct Question {
    let text: String
    let answers: [String]
    let correctAnswerIndex: Int
}

struct QuizView: View {
    let questions: [Question]
    @State private var currentQuestionIndex = 0
    @State private var userScore = 0
    @State private var showingAlert = false
    
    var body: some View {
        VStack{
            if currentQuestionIndex < questions.count{
                Text(questions[currentQuestionIndex].text)
                    .font(.system(size : 38))
                    .bold()
                    .padding()
                
                List(questions[currentQuestionIndex].answers, id: \.self) { answer in
                    Button(action: {
                        self.checkAnswer(answer)
                    }) {
                        Text(answer)
                            .font(.system(size : 32))
                    }
                }
                .listStyle(PlainListStyle())
                
                Text("Score: \(userScore)")
                    .font(.headline)
            }
            if showingAlert == true {
                WinView(currentQuestionIndex: $currentQuestionIndex, userScore: $userScore, showingAlert: $showingAlert)
            }
        }
        .background(Image("batik")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .opacity(0.4)
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .edgesIgnoringSafeArea(.all))
        .padding()
        .accentColor(Color.black)
        
        // Allertview
        //            .alert(isPresented: $showingAlert) {
        //            Alert(
        //                title: Text("Quiz Completed!"),
        //                message:
        //                    Text("Your Score: \(userScore) out of \(questions.count)") +
        //                Text("\nYour Score: \(userScore) out of \(questions.count)"),
        //                dismissButton: .default(Text("Play Again"),
        //                action: {
        //                    restartQuiz()
        //            }))
        //        }
    }
    func checkAnswer(_ answer: String) {
        if let index = questions[currentQuestionIndex].answers.firstIndex(of: answer) {
            if index == questions[currentQuestionIndex].correctAnswerIndex {
                userScore += 1
            }
        }
        
        currentQuestionIndex += 1
        
        if currentQuestionIndex == questions.count{
            showingAlert = true
        }
    }
}

let questions = [
    Question(text: "What is Angklung?", answers: ["A traditional musical instrument from Indonesia", "A type of dance from China", "A type of noodle dish from Thailand", "A traditional musical instrument from Malaysia"], correctAnswerIndex: 0),
    Question(text: "How is Angklung played?", answers: ["By blowing into the instrument", "By plucking the strings", "By striking the bamboo tubes with a mallet", "By shaking the instrument"], correctAnswerIndex: 3),
    Question(text: "What is the traditional role of the Angklung in Indonesian society?", answers: ["Used in everyday life for communication purposes","Used in traditional ceremonies and rituals", "Used for entertainment purposes only", "Used in the military to signal commands"], correctAnswerIndex: 1),
    Question(text: "Which Indonesian island is most commonly associated with Angklung music?", answers: ["Bali", "Sulawesi", "Java", "Sumatra"], correctAnswerIndex: 2),
    Question(text: "How is the pitch of an Angklung determined?", answers: ["By the size of the bamboo tube", "By the color of the bamboo tube", "By the shape of the bamboo tube", "By the number of bamboo tubes used"], correctAnswerIndex: 0),
    Question(text: "What Material Angklung made of?", answers: ["Leather", "Bamboo", "Bronze", "Iron"], correctAnswerIndex: 1)
]

struct Quiz: View {
    var body: some View {
        QuizView(questions: questions)
    }
}

// .frame(width: uiscreen.main.bounds.width)
