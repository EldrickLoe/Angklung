//
//  Play.swift
//  Angklung
//
//  Created by Eldrick Loe on 09/04/23.
//

import SwiftUI
import AVFoundation

struct Play: View {
    @State private var showingPopover = false
    @Binding var backgroundMusicPlayer: AVAudioPlayer?
    @Binding var isPlaying : Bool
    let keys = ["C", "D", "E", "F", "G", "A", "B", "C2", "D2", "E2", "F2", "G2", "A2", "B2", "C3", "D3", "E3", "F3", "G3", "A3", "B3"]
    let labels = ["1", "2", "3", "4", "5", "6", "7", "1", "2", "3", "4", "5", "6", "7", "1", "2", "3", "4", "5", "6", "7"]
    
    var body: some View {
        VStack{
            HStack{
                Spacer()
                Button("How To Play?"){
                    showingPopover = true
                }.popover(isPresented: $showingPopover) {
                    Text("Press the Angklung to play the sound")
                        .font(.headline)
                        .padding()
                    Text("1 = do = C")
                    Text("2 = re = D")
                    Text("3 = mi = E")
                    Text("4 = fa = F")
                    Text("5 = sol = G")
                    Text("6 = la = A")
                    Text("7 = si = B")
                    Text("")
                }
                .padding(.trailing, 30.0)
                .onAppear {
                    backgroundMusicPlayer?.pause()
                }
                .onDisappear {
                    if isPlaying{
                        backgroundMusicPlayer?.play()
                        isPlaying = true
                    } else {
                        backgroundMusicPlayer?.pause()
                        isPlaying = false
                }
                }
            }
            Spacer()
            HStack {
                ForEach(0..<keys.count, id: \.self) { index in
                    VStack {
                        Button{
                            playSound(key: keys[index])
                        }label: {
                            Image("Angklung")
                                .resizable()
                                .scaledToFit()
                                .frame(width: CGFloat(65-index))
                        }
                        Text(labels[index])
                            .font(.system(size: 24))
                    }
                }
            }
            Spacer()
        }
        .background(Image("batik")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .opacity(0.4)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .edgesIgnoringSafeArea(.all))
        //            .background(Color(red: 243/255, green: 222/255, blue: 186/255))
    }
    
}
