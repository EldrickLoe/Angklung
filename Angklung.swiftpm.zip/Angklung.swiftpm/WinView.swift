//
//  WinView.swift
//  Angklung
//
//  Created by Eldrick Loe on 16/04/23.
//
import SwiftUI

struct WinView: View{
    @Binding var currentQuestionIndex : Int
    @Binding var userScore : Int
    @Binding var showingAlert : Bool
    var body: some View{

        ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)){
            VStack{
                Text("Quiz Completed!")
                    .font(.system(size: 32))
                if(userScore <= 2){
                    Image("Sad")
                    Text("Let's Learn More About Angklung!")
                        .font(.system(size: 32))
                }
                else if (userScore <= 5){
                    Image("GoodJob")
                    Text("Not Bad, But You Could Learn More About Angklung ")
                        .font(.system(size: 32))
                }
                else {
                    Image("Amazing")
                    Text("Perfect! You Really Know About Angklung")
                        .font(.system(size: 32))
                }
                Text("Your Score: \(userScore) out of \(questions.count)")
                    .font(.system(size: 32))
                Button(action: {
                    showingAlert = false
                    restartQuiz()
                }){
                    Text("Restart Quiz")
                }
                .frame(width: 200)
                .font(.system(size: 24))
                .foregroundColor(Color.white)
                .background(Color.brown)
                .buttonStyle(.bordered)
                .cornerRadius(10)
                .padding()
            }
            .frame(maxWidth: 750, maxHeight: 750)
            .background(Color.primary.opacity(0.25))
            .cornerRadius(25)
        }
    }
    func restartQuiz() {
         currentQuestionIndex = 0
         userScore = 0
     }
}

