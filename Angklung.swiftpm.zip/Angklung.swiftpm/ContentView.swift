import SwiftUI
import AVFoundation

struct ContentView: View {
    @State var backgroundMusicPlayer: AVAudioPlayer?
    @State var isPlaying = true
    
    var body: some View {
        
        NavigationView{
            VStack {
                HStack{
                    Button(action: {
                            if isPlaying {
                                backgroundMusicPlayer?.pause()
                                isPlaying = false
                            } else {
                                backgroundMusicPlayer?.play()
                                isPlaying = true
                        }
                    }, label: {
                        Text("BGM : ")
                        Image(systemName: isPlaying ? "speaker.fill" : "speaker.slash.fill")
                            .resizable()
                            .frame(width: 30, height: 30)
                            .foregroundColor(.black)
                    })
                    .padding(.leading, 10.0 )
                    Spacer()
                }.padding(.top, 40.0)
                Spacer()
                Image("AngklungTitle")
                Image("Angklung_full")
                    .resizable()
                    .frame(width: 600, height: 500)
                    .scaledToFit()
                
                NavigationLink( destination: Play(backgroundMusicPlayer: $backgroundMusicPlayer, isPlaying: $isPlaying), label:{
                    Text("Play")
                        .frame(width: 400, height: 80)
                        .font(.system(size: 42))
                        .foregroundColor(Color.white)
                        .background(Color.brown)
                        .buttonStyle(.bordered)
                        .cornerRadius(10)
                }
                )
                NavigationLink( destination: AboutAngklung(), label:{
                    Text("About")
                        .frame(width: 400, height: 80)
                        .font(.system(size: 42))
                        .foregroundColor(Color.white)
                        .background(Color.brown)
                        .buttonStyle(.bordered)
                        .cornerRadius(10)
                }
                )
                .padding()
                Spacer()
            }
            .edgesIgnoringSafeArea(.all)
            
            .background(Image("batik")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .opacity(0.4)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .edgesIgnoringSafeArea(.all))
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .accentColor(Color.black)
        .onAppear{
            guard let url = Bundle.main.url(forResource: "bgm", withExtension: "wav") else { return }
            
            do {
                // Create the audio player
                backgroundMusicPlayer = try AVAudioPlayer(contentsOf: url)
                backgroundMusicPlayer?.numberOfLoops = -1 // Loop indefinitely
                backgroundMusicPlayer?.play()
            } catch {
                print("Failed to create background music player: \(error.localizedDescription)")
            }
        }
        
    }
}

